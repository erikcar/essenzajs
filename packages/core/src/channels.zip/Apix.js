import { sleep } from './utils';
import axiosChannel from './channels/AxiosChannel';

//Usa servizio ajax 
console.log("****APIX****");
//Controllo se chiamata ad operazione è già in corso o in coda
//(per le chiamate da eseguire sync potrei anche dare possibilità di dare un riferimento dopo la quale essere eseguita)
//se non trova callID lo mette per ultimo oppure esegue in modo async

//var call_queue = [];
//in questo caso è come se fosse un singleton
var apix = function(channel, retry) {
  this.apiUrl ="Api/";
  this.call_queue = [];
  this.channel = channel || new axiosChannel();
  this.dataOp = "api/jdata";
  this.method = "post";
  this.option = { method: "post", channel: this.channel, parser: null, dataOp: "api/jdata" };
  this.parser = null;//postgreSql;
  this.queryOp = "api/jquery";
  this.retry = retry || new callRetry(3, 500);
  return this;
};

function callRetry(num, wait){
  this.attempts = num;

  if(Array.isArray(wait)){
    this.wait = wait;
  }
  else{
    this.wait = Array(num).fill(wait)
  }
  
  this.count = 0;
  this.onApply = null;
  this.canApply = (er) => this.count < this.attempts;// && er.type !== "RESPONSE";
  this.apply = async (er) => { 
    await sleep(wait[++this.count]);
    if(this.onApply){
      this.onApply(er);
    }
  };
  this.reset = () => this.count = 0;
}

//TODO: Gestire [messaggi utente, progress, assicurarsi di liberare queue, come gestire promise di LOCK (await?)]
apix.fn = apix.prototype = {
  call: function(op, data, opt) {
    console.log("APIX START CALL");
    opt = opt || {};
    opt.url = op;
    opt.data = data;
    console.log("APIX START CALL OPTION", opt);
    this.formatOption(opt);

    //SE è sigleton ed è già in esecuzione DISCARD => restitusco direttamente errore di  Promise.reject({type: ''});
    // canExecute può essere ['SINGLETON', 'LOCK', 'PARALLEL'] ma PARALLEL implica che può fare la chiamata senza controlli quindi si lascia canExecute undefined
    if (opt.mode && !this.CanExecute(op, opt)) {
      if(opt.mode === 'SINGLETON')
      {
        return Promise.reject({type: 'DISCARD'});
      }
      else{ //LOCK case => put ACTION in queue
        let callObj = { id: op, option: opt, resolve: null, reject: null}
        this.CanExecutecall_queue.push(callObj);
        opt.lock = true;
        return new Promise(function(resolve, reject) {callObj.resolve = resolve; callObj.reject = reject;});
      } 
    }

    // SE DEVO METTERE IN CODA COSA RESTITUISCO? un promise che aspetta il suo turno ed eventualmente ha un meccanismo per eliminarsi da coda dopo un certo timeout
    //Sarebbe ottimo uno scheduler simple and light
    let instance = this;
    opt.promise = new Promise(function(resolve, reject) {
      instance.rawCall(opt, resolve, reject);
    });

    return opt.promise;
  },

  CanExecute: function(id, mode) {
    mode = mode || this.option.mode;
    console.log("PASSA CanExecute: ", id);
  
    if(this.findCall(id)>-1 && (mode === 'SINGLETON' || mode === 'LOCK') )
    {
        return false;
    }
  
    return true;
  },

  callMany: function() {},

  checkQueue: function (config){
    config = config || this.option;

    if(config.mode)
    {
      let index = this.findCall(config.url);
      
      //Attenzione se faccio chiamata ad id dopo che ho eliminato potrei eseguire insieme così
      if( index > -1 ){
        if(config.mode === 'LOCK'){
          //DO el call esegue adesso chiamata AXIOS
          let call = this.call_queue[index];
          const opt = call.option;
          this.call(opt.url, opt.data, opt).then(result=>call.resolve(result)).catch(reason=>call.reject(reason));
        }
        this.call_queue.splice(index, 1)
      }
    }
  },

  findCall: function (id){
   return this.call_queue.findIndex(e=>e.id = id);
  },

  formatOption: function(opt){
    let defaultOption = this.option;

    for (let key in defaultOption) {
      if (!opt.hasOwnProperty(key)) {
        opt[key] = defaultOption[key];
      }
    }
    opt.attempt = opt.attempt || 3;
    
    //if(!opt.channel) { opt.channel = this.channel; }
    //if(!opt.parser) { opt.parser = this.parser; }
  },

  rawCall: function(opt, resolve, reject){
    let channel = opt.channel;
    let instance = this;
    console.log("APIX RAW CALL: ", opt);
    channel.send(opt)
      .then((response) => {
        //GESTIRE ACTION ON RESULT - FACCIO PRIMA O DOPO resolve? ovvero faccio eventuale chiamata prima che venga gestita?
        this.checkQueue(response.config);
        response.config.promise = null; //Si può? delete? non viene comunque liberata da axios?
        resolve({
          data: response.data,
          args: response.config.args,
          opt: response.config,
        });
      })
      .catch(function(error) {
        let retry = opt.retry || instance.retry;
        console.log(error, retry);
        if (retry && retry.canApply(error)) {
          console.log("TENTATIVO: ", retry.count);
          retry.apply(opt);
          instance.rawCall(opt, resolve, reject);
        } 
        else {
          this.checkQueue(opt);//error.config);
          reject(error);
          //Log to server error.message?
        }
      });
  },
  syncCall: function() {}, // Serve sol per canExecute di client Action (che non prevedono chiamate remote o async)
};

export const Apix = new apix();
//Potrei creare object o class Request con tutte le info per eseguire la call
//Da esportare, esiste caso in cui stessa op viene chiamata
/**
 *
 * @param {operation} op
 * @param {*Data to send} data
 * @param {*option of axios more args} opt
 */

/*function progressWidth(evt) {
  if (evt.lengthComputable) {
    var percentComplete = evt.loaded / evt.total;
    console.log(percentComplete);
    $(".lbn-progress").css({
      width: percentComplete * 100 + "%",
    });
  }
}
function CanExecute(id, config) {
  
  console.log("PASSA CanExecute: ", id);

  if(findCall(id)>-1 && (config.mode === 'SINGLETON' || config.mode === 'LOCK') )
  {
      return false;
  }

  return true;
}

function findCall(id){
   /*
  for (var i = 0; i < call_queue.length; i++) {
    if (call_queue[i].id == id) {
      return  i;
    }
  } return -1;/
  return this.call_queue.findIndex(e=>e.id = id);
}

function checkQueue(config){
  if(config.mode)
  {
    let index = findCall(config.url);
    
    //Attenzione se faccio chiamata ad id dopo che ho eliminato potrei eseguire insieme così
    if( index > -1 ){
      if(config.mode === 'LOCK'){
        //DO el call esegue adesso chiamata AXIOS
        let call = call_queue[index];
        const opt = call.option;
        Apix.call(opt.url, opt.data, opt).then(result=>call.resolve(result)).catch(reason=>call.reject(reason));
      }
      call_queue.splice(index, 1)
    }
  }
}
*/

//be javascript in browser single thread would be safe index (not change) between findCall and remove


